/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3_golpedopix;
import javax.swing.JOptionPane;
/**
 *
 * @author profslabs
 */
public class TransacaoPix {
    protected String remetente;
    protected double valor;
    protected String mensagem;

    public TransacaoPix(String remetente, double valor, String mensagem) {
        this.remetente = remetente;
        this.valor = valor;
        this.mensagem = mensagem;
    }

    public boolean verificarGolpe() {
        return mensagem.toLowerCase().contains("presente") || (mensagem.contains("frete") || mensagem.contains("pagamento")|| mensagem.contains("pague"));
    }
}
