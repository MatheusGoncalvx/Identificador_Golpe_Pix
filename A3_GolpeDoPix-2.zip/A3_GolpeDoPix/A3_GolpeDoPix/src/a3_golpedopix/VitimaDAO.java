/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3_golpedopix;
import java.sql.*;
import java.util.ArrayList;

public class VitimaDAO {

    public static void criarTabela() {
        String sql = "CREATE TABLE IF NOT EXISTS vitima (" +
                     "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                     "nome TEXT, cpf TEXT, banco TEXT, tipoGolpe TEXT)";
        try (Connection conn = ConexaoBD.conectar(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("Erro ao criar tabela: " + e.getMessage());
        }
    }

    //CREATE
    public static void inserir(Vitima v) {
        String sql = "INSERT INTO vitima (nome, cpf, banco, tipoGolpe) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexaoBD.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, v.getNome());
            pstmt.setString(2, v.getCpf());
            pstmt.setString(3, v.getBanco());
            pstmt.setString(4, v.getTipoGolpe().toString());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir v�tima: " + e.getMessage());
        }
    }
    //READ
    public static ArrayList<Vitima> listar() {
        ArrayList<Vitima> lista = new ArrayList<>();
        String sql = "SELECT * FROM vitima";
        try (Connection conn = ConexaoBD.conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Vitima v = new Vitima(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("cpf"),
                    rs.getString("banco"),
                    TipoGolpe.valueOf(rs.getString("tipoGolpe"))
                );
                lista.add(v);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar v�timas: " + e.getMessage());
        }
        return lista;
    }
    //UPDATE
    public static void atualizar(Vitima v) {
    String sql = "UPDATE vitima SET nome = ?, cpf = ?, banco = ?, tipoGolpe = ? WHERE id = ?";
    try (Connection conn = ConexaoBD.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, v.getNome());
        pstmt.setString(2, v.getCpf());
        pstmt.setString(3, v.getBanco());
        pstmt.setString(4, v.getTipoGolpe().toString());
        pstmt.setInt(5, v.getId());
        pstmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Erro ao atualizar v�tima: " + e.getMessage());
    }
}
    //DELETE
    public static void excluir(int id) {
    String sql = "DELETE FROM vitima WHERE id = ?";
    try (Connection conn = ConexaoBD.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, id);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Erro ao excluir v�tima: " + e.getMessage());
    }
}
    
}