/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3_golpedopix;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBD {
    private static final String URL = "jdbc:sqlite:A3_GOLPE.sql";
    private static Connection conexao;


    public static Connection conectar() {
    try {
        if (conexao == null || conexao.isClosed()) {
            conexao = DriverManager.getConnection(URL);
            System.out.println("Conectado ao banco de dados.");
        }
    } catch (SQLException e) {
        System.out.println("Erro ao conectar: " + e.getMessage());
    }
    return conexao;
}

    public static void desconectar() {
        if (conexao != null) {
            try {
                conexao.close();
                conexao = null;
                System.out.println("Conex�o encerrada.");
            } catch (SQLException e) {
                System.out.println("Erro ao desconectar: " + e.getMessage());
            }
        }
    }
}