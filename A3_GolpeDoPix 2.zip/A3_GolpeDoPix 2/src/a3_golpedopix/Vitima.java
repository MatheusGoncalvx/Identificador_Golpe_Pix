/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3_golpedopix;

/**
 *
 * @author profslabs
 */
public class Vitima {
     private int id; // id gerado pelo banco de dados
    private String nome;
    private String cpf;
    private String banco;
    private TipoGolpe tipoGolpe; // enum com o tipo do golpe

    // Construtor sem id (para inser��o)
    public Vitima(String nome, String cpf, String banco, TipoGolpe tipoGolpe) {
        this.nome = nome;
        this.cpf = cpf;
        this.banco = banco;
        this.tipoGolpe = tipoGolpe;
    }

    // Construtor com id (para recupera��o do banco)
    public Vitima(int id, String nome, String cpf, String banco, TipoGolpe tipoGolpe) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.banco = banco;
        this.tipoGolpe = tipoGolpe;
    }

    // Getters e setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
   
    public String getBanco() {
        return banco;
    }
    public void setBanco(String banco) {
        this.banco = banco;
    }
    public TipoGolpe getTipoGolpe() {
        return tipoGolpe;
    }
    public void setTipoGolpe(TipoGolpe tipoGolpe) {
        this.tipoGolpe = tipoGolpe;
    }

    // toString para facilitar visualiza��o
    @Override
    public String toString() {
        return "Vitima{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", cpf='" + cpf + '\'' +
                ", banco='" + banco + '\'' +
                ", tipoGolpe=" + tipoGolpe +
                '}';
    }
}
    

