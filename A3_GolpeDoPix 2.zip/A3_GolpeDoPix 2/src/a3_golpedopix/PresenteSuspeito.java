package a3_golpedopix;

import javax.swing.JOptionPane;
import java.awt.Desktop;
import java.net.URI;

public class PresenteSuspeito extends TransacaoPix {

    public PresenteSuspeito(String remetente, double valor, String mensagem) {
        super(remetente, valor, mensagem);
    }

    public void alertaGolpe() {
        JOptionPane.showMessageDialog(
            null,
            "? Aten��o! Essa transa��o parece ser um golpe.\n" + "Remetente: " + remetente + "\nValor: R$ " + valor, "Alerta de Golpe", JOptionPane.WARNING_MESSAGE ); //mensagem de alerta diante ao golpe que foi aplicado 

        // Coleta os dados da v�tima
        String nome = JOptionPane.showInputDialog("Digite seu nome completo:");
        String cpf = JOptionPane.showInputDialog("Digite seu CPF:");
        String banco = JOptionPane.showInputDialog("Informe o banco onde ocorreu o golpe:");

        // Cria��o do objeto Vitima
        Vitima vitima = new Vitima(nome, cpf, banco, TipoGolpe.PRESENTE);

        // Pergunta se deseja fazer boletim de ocorr�ncia
        int golpe = JOptionPane.showConfirmDialog(
            null,
            "O valor ser� depositado, deseja realizar um boletim de ocorr�ncia?",
            "Confirma��o",
            JOptionPane.YES_NO_OPTION
        );

        if (golpe == JOptionPane.YES_OPTION) { // verifica se a pessoa pagou o valor do golpe 
            try {
                Desktop.getDesktop().browse(new URI("https://www.delegaciaeletronica.policiacivil.sp.gov.br"));//puxa a o link e direciona diretamente eao site para a fazer o boletim
            } catch (Exception e) {
                JOptionPane.showMessageDialog(
                    null,
                    "Erro ao abrir o site. Acesse manualmente:\nhttps://www.delegaciaeletronica.policiacivil.sp.gov.br",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        } else { // se n�o foi pago mostra a mensagem de alerta 
            JOptionPane.showMessageDialog(
                null,
                "Fique atento com golpes, sempre verifique!",
                "Aviso",
                JOptionPane.WARNING_MESSAGE
            );
        }

        // Insere no banco de dados
        VitimaDAO.inserir(vitima); // insere no banco de dados da vitima 
    }
}
