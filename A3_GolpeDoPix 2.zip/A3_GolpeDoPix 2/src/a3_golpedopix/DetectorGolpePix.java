package a3_golpedopix;

import javax.swing.JOptionPane;

public class DetectorGolpePix {
    public static void main(String[] args) {
        VitimaDAO.criarTabela();    
        JOptionPane.showMessageDialog(null,  "? Sistema de Verifica��o Antifraude - Golpe do Pix", "Detector de Golpe", JOptionPane.INFORMATION_MESSAGE); //mensagem de abertura do sistema

        
        //obtendo informa��es do golpe 
        String remetente = JOptionPane.showInputDialog("Informe o nome do remetente:");
        double valor = Double.parseDouble(JOptionPane.showInputDialog("Qual o valor do Pix?"));
        String mensagem = JOptionPane.showInputDialog("Digite a mensagem recebida:");

        //criando o objeto TransacaoPix
        TransacaoPix transacao = new TransacaoPix(remetente, valor, mensagem);

        //confirmando se o usu�rio pagou o valor do golpe 
        int resposta = JOptionPane.showConfirmDialog(
            null,
            "Voc� pagou o valor requisitado?",
            "Confirma��o",
            JOptionPane.YES_NO_OPTION
        );
        // se sim emite para ir o banco de vitimas
        if (resposta == JOptionPane.YES_OPTION) {
            if (transacao.verificarGolpe()) {
                PresenteSuspeito suspeito = new PresenteSuspeito(remetente, valor, mensagem);
                suspeito.alertaGolpe();
            }
        } else if (resposta == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "Fique atento com golpes, sempre verifique!!",  "Aviso", JOptionPane.WARNING_MESSAGE);
        }
      
    }
}
