CREATE DATABASE A3_GOLPE;

USE A3_GOLPE;
--
CREATE TABLE vitima (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf TEXT NOT NULL,
    selfiePath TEXT,
    banco TEXT NOT NULL,
    tipoGolpe TEXT NOT NULL
);
